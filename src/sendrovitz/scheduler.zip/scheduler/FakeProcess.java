package sendrovitz.scheduler;

public class FakeProcess {
	private int priority;
	private int timeToCompletion;
	
	public FakeProcess(){
		
	}
	public void run(int time){
		timeToCompletion-=time;
	}
	public boolean isStillRunning(){
		if(timeToCompletion<=0){
			return false;
		}
		return true;
	}
}
